//simle declare classes who's use in the document
const score = document.querySelector('.score');
const pop_up = document.querySelector('.pop-up');
const ground = document.querySelector('.ground');

//Events....
document.addEventListener('keydown', keyDown);
document.addEventListener('keyup', keyUp);
pop_up.addEventListener('click', start);


let player = {
    speed: 5,
    score: 0
}

//by defaut keys is false

let keys = {
    ArrowDown: false,
    ArrowUp: false,
    ArrowLeft: false,
    ArrowRight: false
}

//if key is press down then key true(mean running)
function keyDown(e) {
    e.preventDefault();
    keys[e.key] = true;
}

//if key is press-up the key is false(mean fasle-stop)
function keyUp(e) {
    e.preventDefault();
    keys[e.key] = false;
}

for (let x = 0; x < 5; x++) {
    const lines = document.createElement('div');
    lines.setAttribute('class', 'lines');
    lines.y = (x * 150);
    lines.style.top = lines.y + 'px';
    ground.appendChild(lines);
}

function start() {
    pop_up.classList.add('hide');
    ground.innerHTML = "";

    const car = document.createElement('div');
    car.setAttribute('class', 'car');
    ground.appendChild(car);

    //multiple lines of road
    for (let x = 0; x < 5; x++) {
        const lines = document.createElement('div');
        lines.setAttribute('class', 'lines');
        lines.y = (x * 150);
        lines.style.top = lines.y + 'px';
        ground.appendChild(lines);
    }

    //multiple cars of enemy
    for (let x = 0; x < 3; x++) {
        const enemy = document.createElement('div');
        enemy.setAttribute('class', 'enemy');
        enemy.y = ((x + 1) * 350) * -1;
        enemy.style.top = enemy.y + 'px';
        enemy.style.backgroundColor = randomColor();
        enemy.style.left = Math.floor(Math.random() * 350) + 'px';
        ground.appendChild(enemy);
    }

    player.x = car.offsetLeft;
    player.y = car.offsetTop;

    player.start = true;
    player.score = 0;

    window.requestAnimationFrame(runGame);
}

function runGame() {

    const car = document.querySelector('.car');
    let road = ground.getBoundingClientRect();
    // console.log(road);

    if (player.start) {
        moveLines();
        moveEnemy(car);

        if (keys.ArrowDown && player.y < (road.height - 90)) {
            player.y += player.speed;
        }
        if (keys.ArrowUp && player.y > 70) {
            player.y -= player.speed;
        }
        if (keys.ArrowLeft && player.x > 0) {
            player.x -= player.speed;
        }
        if (keys.ArrowRight && player.x < (road.width - 90)) {
            player.x += player.speed;
        }


        car.style.top = player.y + 'px';
        car.style.left = player.x + 'px';

        // console.log("hello this is world");
        window.requestAnimationFrame(runGame);
        player.score++;
        score.innerText = "Score: " + player.score;
    }

}

//animation lines moves
function moveLines() {
    const moveLines = document.querySelectorAll('.lines');

    moveLines.forEach((item) => {
        if (item.y == 700) {
            item.y -= 750;
        }
        item.y += player.speed;
        item.style.top = item.y + 'px';
    });
}

function moveEnemy(car) {
    const moveEnemy = document.querySelectorAll('.enemy');

    moveEnemy.forEach((item) => {
        if (isCollapse(car, item)) {
            // player.start = false;
            endGame();
        }

        if (item.y == 750) {
            item.y = -300;
            item.style.left = Math.floor(Math.random() * 320) + 'px';
        }
        item.y += player.speed;
        item.style.top = item.y + 'px';
    });
}
function endGame(){
    player.start = false;
    pop_up.classList.remove('hide');
}

//a mean my car /b mean enemy car
function isCollapse(a, b) {
    let aRect = a.getBoundingClientRect();
    let bRect = b.getBoundingClientRect();

    return !((aRect.bottom < bRect.top) || (aRect.top > bRect.bottom) || (aRect.right < bRect.left) ||
        (aRect.left > bRect.right));
}

function randomColor(){
    function c(){
        let hex = Math.floor(Math.random() * 256).toString(16);
        return ("0" + String(hex)).substr(-2);
        console.log(hex)
    }
    return "#" + c()+c()+c();
}
